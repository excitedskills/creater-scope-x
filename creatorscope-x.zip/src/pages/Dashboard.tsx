import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Youtube, BookOpen, Globe, Star, Trash2, ArrowRight, Loader2, UserPlus } from "lucide-react";
import { motion } from "motion/react";
import { db } from "../firebase";
import { collection, onSnapshot, query, orderBy } from "firebase/firestore";

interface DashboardProps {
  user: any;
}

export default function Dashboard({ user }: DashboardProps) {
  const [creators, setCreators] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, "users", user.uid, "trackedCreators"),
      orderBy("addedAt", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const creatorsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setCreators(creatorsData);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center bg-[#050505] text-white px-4">
        <UserPlus className="w-16 h-16 text-[#F27D26] mb-6" />
        <h2 className="text-4xl font-bold uppercase italic mb-4 tracking-tighter">Account Required</h2>
        <p className="text-white/40 mb-12 max-w-md text-center">Connect your account to start tracking creators, saving analytics, and generating AI insights.</p>
        <button className="px-12 py-4 bg-[#F27D26] text-black font-bold uppercase tracking-widest hover:bg-[#ff8c3a] transition-colors rounded-sm">Connect Now</button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center bg-[#050505] text-white">
        <Loader2 className="w-12 h-12 text-[#F27D26] animate-spin mb-4" />
        <p className="text-white/40 uppercase tracking-widest font-bold text-xs animate-pulse">Loading Watchlist...</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex justify-between items-end mb-16">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#F27D26] mb-2 block">User Dashboard</span>
          <h1 className="text-6xl font-bold tracking-tighter uppercase italic">My Watchlist</h1>
        </div>
        <div className="text-right hidden md:block">
          <div className="text-xs font-bold uppercase tracking-widest text-white/40 mb-1">Tracked Creators</div>
          <div className="text-4xl font-bold tracking-tighter">{creators.length}</div>
        </div>
      </div>

      {creators.length === 0 ? (
        <div className="bg-white/5 border border-dashed border-white/20 rounded-sm p-20 text-center">
          <Star className="w-12 h-12 text-white/20 mx-auto mb-6" />
          <h3 className="text-2xl font-bold uppercase italic mb-4 tracking-tight">Your watchlist is empty</h3>
          <p className="text-white/40 mb-8 max-w-sm mx-auto">Start by searching for a creator on the homepage and clicking the star icon to track them.</p>
          <Link to="/" className="inline-flex items-center gap-2 px-8 py-3 bg-white/10 text-white font-bold uppercase tracking-widest hover:bg-white/20 transition-colors rounded-sm">
            Explore Creators <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {creators.map((creator, i) => (
            <motion.div 
              key={creator.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              className="bg-white/5 border border-white/10 p-8 rounded-sm hover:border-[#F27D26]/50 transition-all group relative"
            >
              <div className="flex items-center gap-4 mb-8">
                <img src={creator.thumbnail} alt={creator.name} className="w-16 h-16 rounded-sm object-cover border border-white/10" />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    {creator.platform === 'youtube' ? <Youtube className="w-3 h-3 text-red-500" /> : creator.platform === 'medium' ? <BookOpen className="w-3 h-3 text-green-500" /> : <Globe className="w-3 h-3 text-orange-500" />}
                    <span className="text-[8px] font-bold uppercase tracking-widest text-white/40">{creator.platform}</span>
                  </div>
                  <h3 className="text-xl font-bold uppercase italic tracking-tight group-hover:text-[#F27D26] transition-colors line-clamp-1">{creator.name}</h3>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-black/40 p-3 rounded-sm border border-white/5">
                  <div className="text-[8px] font-bold uppercase tracking-widest text-white/20 mb-1">Added</div>
                  <div className="text-xs font-bold">{new Date(creator.addedAt).toLocaleDateString()}</div>
                </div>
                <div className="bg-black/40 p-3 rounded-sm border border-white/5">
                  <div className="text-[8px] font-bold uppercase tracking-widest text-white/20 mb-1">Status</div>
                  <div className="text-xs font-bold text-green-500">Tracking</div>
                </div>
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={() => navigate(`/creator/${creator.platform}/${creator.externalId}`)}
                  className="flex-1 py-3 bg-white/10 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-white/20 transition-all rounded-sm"
                >
                  View Analytics
                </button>
                <button className="px-4 py-3 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-all rounded-sm border border-red-500/20">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
