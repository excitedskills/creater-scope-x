import { useEffect, useState } from "react";
import { useParams, useLocation } from "react-router-dom";
import { Youtube, BookOpen, Globe, TrendingUp, Users, Eye, Video, Calendar, Star, Share2, Download, Loader2, Sparkles, AlertCircle, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import axios from "axios";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import ReactMarkdown from "react-markdown";
import { auth, db } from "../firebase";
import { doc, setDoc, deleteDoc, getDoc } from "firebase/firestore";
import { GoogleGenAI } from "@google/genai";

export default function CreatorProfile() {
  const { platform, id } = useParams();
  const location = useLocation();
  const [data, setData] = useState<any>(location.state?.initialData || null);
  const [insights, setInsights] = useState<string>("");
  const [loading, setLoading] = useState(!location.state?.initialData);
  const [insightsLoading, setInsightsLoading] = useState(false);
  const [insightsError, setInsightsError] = useState("");
  const [isSaved, setIsSaved] = useState(false);
  const [showLiveCounter, setShowLiveCounter] = useState(false);
  const [liveSubs, setLiveSubs] = useState(0);
  const [error, setError] = useState("");
  const [currency, setCurrency] = useState<'USD' | 'INR'>('USD');

  const EXCHANGE_RATE = 83; // 1 USD = 83 INR

  const formatCurrency = (value: number) => {
    if (currency === 'INR') {
      return `₹${Math.floor(value * EXCHANGE_RATE).toLocaleString('en-IN')}`;
    }
    return `$${Math.floor(value).toLocaleString()}`;
  };

  useEffect(() => {
    let interval: any;
    if (showLiveCounter && data) {
      setLiveSubs(data.stats.subscribers);
      interval = setInterval(() => {
        setLiveSubs(prev => prev + Math.floor(Math.random() * 5));
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [showLiveCounter, data]);

  const [timeframe, setTimeframe] = useState<7 | 30>(7);

  useEffect(() => {
    if (data) {
      console.log("CreatorProfile: Exposing data for AI Assistant:", data.name);
      // Expose data to global window for AI Assistant to pick up
      (window as any).currentCreatorData = data;
    }
  }, [data]);

  const chartData = (data?.advanced?.history || [
    { name: "Day 1", views: 4000, subs: 2400, subGains: 120, viewGains: 1500 },
    { name: "Day 2", views: 3000, subs: 1398, subGains: 150, viewGains: 1200 },
    { name: "Day 3", views: 2000, subs: 9800, subGains: 180, viewGains: 1800 },
    { name: "Day 4", views: 2780, subs: 3908, subGains: 140, viewGains: 1400 },
    { name: "Day 5", views: 1890, subs: 4800, subGains: 160, viewGains: 1600 },
    { name: "Day 6", views: 2390, subs: 3800, subGains: 200, viewGains: 2200 },
    { name: "Day 7", views: 3490, subs: 4300, subGains: 190, viewGains: 2000 },
  ]).slice(-timeframe);

  useEffect(() => {
    if (!data) {
      fetchData();
    }
    checkIfSaved();
  }, [id]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // For demo, we'll re-analyze the URL or use a mock URL based on ID
      const mockUrl = platform === 'youtube' ? `https://youtube.com/channel/${id}` : `https://${platform}.com/${id}`;
      const response = await axios.post("/api/analyze", { url: mockUrl });
      setData(response.data);
    } catch (err: any) {
      setError("Failed to fetch creator data.");
    } finally {
      setLoading(false);
    }
  };

  const generateInsights = async () => {
    if (!data) return;
    setInsightsLoading(true);
    setInsightsError("");
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
        throw new Error("Gemini API Key is missing. Please add GEMINI_API_KEY to Settings > Secrets in AI Studio.");
      }
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `Analyze this creator's stats and provide growth insights and predictions.
    Name: ${data.name}
    Platform: ${platform}
    Subscribers/Followers: ${data.stats?.subscribers || 'N/A'}
    Total Views: ${data.stats?.views || 'N/A'}
    Content Count: ${data.stats?.videoCount || data.stats?.posts || 'N/A'}
    
    Provide:
    1. A "Viral Score" (0-100) based on engagement.
    2. 7-day and 30-day growth predictions.
    3. 3 actionable content strategy tips.
    4. Best posting time suggestion.
    
    Format the response in Markdown.`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ parts: [{ text: prompt }] }],
      });

      if (!response.text) {
        throw new Error("No response text from AI model");
      }

      setInsights(response.text);
    } catch (err: any) {
      console.error("Failed to generate insights", err);
      let errorMessage = err.message || "Failed to generate AI insights. Please try again.";
      if (errorMessage.includes("API key not valid")) {
        errorMessage = "Gemini API Key is invalid. Please ensure you have a valid key in AI Studio.";
      }
      setInsightsError(errorMessage);
    } finally {
      setInsightsLoading(false);
    }
  };

  const checkIfSaved = async () => {
    if (!auth.currentUser) return;
    const docRef = doc(db, "users", auth.currentUser.uid, "trackedCreators", id!);
    const docSnap = await getDoc(docRef);
    setIsSaved(docSnap.exists());
  };

  const toggleSave = async () => {
    if (!auth.currentUser) {
      alert("Please connect your account to save creators.");
      return;
    }
    const docRef = doc(db, "users", auth.currentUser.uid, "trackedCreators", id!);
    if (isSaved) {
      await deleteDoc(docRef);
      setIsSaved(false);
    } else {
      await setDoc(docRef, {
        id,
        userId: auth.currentUser.uid,
        platform,
        externalId: id,
        name: data.name,
        thumbnail: data.thumbnail,
        addedAt: new Date().toISOString(),
      });
      setIsSaved(true);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#050505] text-white">
        <Loader2 className="w-12 h-12 text-[#F27D26] animate-spin mb-4" />
        <p className="text-white/40 uppercase tracking-widest font-bold text-xs animate-pulse">Analyzing Data Pipeline...</p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#050505] text-white px-4">
        <AlertCircle className="w-16 h-16 text-red-500 mb-6" />
        <h2 className="text-3xl font-bold uppercase italic mb-2 tracking-tighter">Analysis Failed</h2>
        <p className="text-white/40 mb-8 max-w-md text-center">{error || "We couldn't find data for this creator. Please check the URL and try again."}</p>
        <button onClick={() => window.history.back()} className="px-8 py-3 bg-white/10 text-white font-bold uppercase tracking-widest hover:bg-white/20 transition-colors rounded-sm">Go Back</button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="relative mb-20">
        {data.banner && (
          <div className="h-48 w-full rounded-sm overflow-hidden mb-8 border border-white/10">
            <img src={data.banner} alt="Banner" className="w-full h-full object-cover opacity-50" />
          </div>
        )}
        
        <div className="flex flex-col md:flex-row gap-8 items-start md:items-end">
          <div className="relative">
            <img src={data.thumbnail} alt={data.name} className="w-32 h-32 rounded-sm border-4 border-[#050505] shadow-2xl relative z-10" />
            <div className="absolute -inset-1 bg-[#F27D26] blur-lg opacity-20"></div>
          </div>
          
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              {platform === 'youtube' ? <Youtube className="w-5 h-5 text-red-500" /> : platform === 'medium' ? <BookOpen className="w-5 h-5 text-green-500" /> : <Globe className="w-5 h-5 text-orange-500" />}
              <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">{platform} Creator</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tighter uppercase italic leading-none mb-4">{data.name}</h1>
            <p className="text-white/60 max-w-2xl text-sm line-clamp-2">{data.description}</p>
          </div>

          <div className="flex gap-3">
            <button 
              onClick={toggleSave}
              className={`p-4 rounded-sm border transition-all ${isSaved ? 'bg-[#F27D26] border-[#F27D26] text-black' : 'bg-white/5 border-white/10 text-white hover:border-[#F27D26]'}`}
            >
              <Star className={`w-5 h-5 ${isSaved ? 'fill-black' : ''}`} />
            </button>
            <button className="p-4 bg-white/5 border border-white/10 rounded-sm hover:border-[#F27D26] transition-all">
              <Share2 className="w-5 h-5" />
            </button>
            <button className="p-4 bg-white/5 border border-white/10 rounded-sm hover:border-[#F27D26] transition-all">
              <Download className="w-5 h-5" />
            </button>
            <div className="flex bg-white/5 border border-white/10 rounded-sm p-1">
              <button 
                onClick={() => setCurrency('USD')}
                className={`px-3 py-2 text-[10px] font-bold uppercase tracking-widest rounded-sm transition-all ${currency === 'USD' ? 'bg-[#F27D26] text-black' : 'text-white/40 hover:text-white'}`}
              >
                USD
              </button>
              <button 
                onClick={() => setCurrency('INR')}
                className={`px-3 py-2 text-[10px] font-bold uppercase tracking-widest rounded-sm transition-all ${currency === 'INR' ? 'bg-[#F27D26] text-black' : 'text-white/40 hover:text-white'}`}
              >
                INR
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
        <div className="bg-white/5 border border-white/10 p-6 rounded-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2">
            <div className="text-[10px] font-black bg-[#F27D26] text-black px-2 py-0.5 rounded-sm">GRADE {data.advanced?.grade || 'C'}</div>
          </div>
          <div className="flex items-center gap-3 mb-4 text-white/40">
            <Users className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">Subscribers</span>
          </div>
          <div className="text-3xl font-bold tracking-tighter">{(data.stats.subscribers || 0).toLocaleString()}</div>
          <div className="text-[10px] text-green-500 font-bold uppercase tracking-widest mt-2">Rank: #{data.advanced?.rank?.toLocaleString() || 'N/A'}</div>
          
          <button 
            onClick={() => setShowLiveCounter(true)}
            className="absolute inset-0 bg-[#F27D26]/90 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-black font-bold uppercase tracking-widest text-xs"
          >
            <Sparkles className="w-4 h-4" />
            Live Counter
          </button>
        </div>
        <div className="bg-white/5 border border-white/10 p-6 rounded-sm">
          <div className="flex items-center gap-3 mb-4 text-white/40">
            <Eye className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">Total Views</span>
          </div>
          <div className="text-3xl font-bold tracking-tighter">{(data.stats.views || 0).toLocaleString()}</div>
          <div className="text-[10px] text-green-500 font-bold uppercase tracking-widest mt-2">+12.8% this week</div>
        </div>
        <div className="bg-white/5 border border-white/10 p-6 rounded-sm">
          <div className="flex items-center gap-3 mb-4 text-white/40">
            <Video className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">Content Count</span>
          </div>
          <div className="text-3xl font-bold tracking-tighter">{data.stats.videoCount || data.stats.posts || 0}</div>
          <div className="text-[10px] text-white/20 font-bold uppercase tracking-widest mt-2">Lifetime uploads</div>
        </div>
        <div className="bg-white/5 border border-white/10 p-6 rounded-sm">
          <div className="flex items-center gap-3 mb-4 text-white/40">
            <TrendingUp className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">Est. Monthly Earnings</span>
          </div>
          <div className="text-3xl font-bold tracking-tighter text-green-500">
            {formatCurrency(data.advanced?.earnings?.monthlyLow || 0)} - {formatCurrency(data.advanced?.earnings?.monthlyHigh || 0)}
          </div>
          <div className="text-[10px] text-white/20 font-bold uppercase tracking-widest mt-2">Based on CPM estimates</div>
        </div>
      </div>

      {/* Social Blade Specifics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
        <div className="bg-white/5 border border-white/10 p-8 rounded-sm">
          <h3 className="text-xl font-bold uppercase italic tracking-tight mb-8">Future Projections</h3>
          <div className="space-y-4">
            {data.advanced?.projections?.map((proj: any) => (
              <div key={proj.timeframe} className="flex justify-between items-center p-4 bg-white/5 rounded-sm border border-white/5">
                <span className="text-sm font-bold uppercase tracking-widest text-white/60">{proj.timeframe}</span>
                <span className="text-xl font-bold tracking-tighter text-[#F27D26]">{proj.subs.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white/5 border border-white/10 p-8 rounded-sm">
          <h3 className="text-xl font-bold uppercase italic tracking-tight mb-8">Estimated Yearly Earnings</h3>
          <div className="flex flex-col justify-center h-full pb-8">
            <div className="text-6xl font-black text-green-500 tracking-tighter mb-2">
              {formatCurrency(data.advanced?.earnings?.yearlyLow || 0)} - {formatCurrency(data.advanced?.earnings?.yearlyHigh || 0)}
            </div>
            <p className="text-white/40 text-xs uppercase tracking-widest font-bold">Estimated Yearly Revenue</p>
            <div className="mt-8 p-4 bg-white/5 border border-white/10 rounded-sm">
              <p className="text-[10px] text-white/40 uppercase tracking-widest leading-relaxed">
                Note: These figures are estimates based on average CPM rates ($0.25 - $4.00) and do not account for sponsorships, merchandise, or other revenue streams.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Daily Stats Table */}
      <div className="bg-white/5 border border-white/10 rounded-sm overflow-hidden mb-12">
        <div className="p-6 border-b border-white/10 bg-white/5">
          <h3 className="text-xl font-bold uppercase italic tracking-tight">Recent Daily Performance</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-[10px] font-bold uppercase tracking-widest text-white/40 border-b border-white/10 bg-white/5">
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Subscribers Gained</th>
                <th className="px-6 py-4">Views Gained</th>
                <th className="px-6 py-4">Est. Earnings</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {[...(data?.advanced?.history || [])].reverse().slice(0, 7).map((day: any, i: number) => {
                return (
                  <tr key={i} className="hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-white/60">{day.name}</td>
                    <td className="px-6 py-4 text-sm font-bold text-green-500">+{day.subGains.toLocaleString()}</td>
                    <td className="px-6 py-4 text-sm font-bold">+{day.viewGains.toLocaleString()}</td>
                    <td className="px-6 py-4 text-sm font-bold text-green-500">{formatCurrency((day.viewGains / 1000) * 1.5)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Live Counter Modal */}
      <AnimatePresence>
        {showLiveCounter && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLiveCounter(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-[#111] border border-white/10 p-12 rounded-sm max-w-2xl w-full text-center shadow-2xl"
            >
              <button 
                onClick={() => setShowLiveCounter(false)}
                className="absolute top-4 right-4 text-white/40 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
              
              <div className="flex items-center justify-center gap-4 mb-8">
                <div className="w-16 h-16 bg-[#F27D26] rounded-sm flex items-center justify-center">
                  <Users className="w-8 h-8 text-black" />
                </div>
                <div className="text-left">
                  <h2 className="text-3xl font-bold uppercase italic tracking-tight">{data.name}</h2>
                  <p className="text-[#F27D26] text-xs font-bold uppercase tracking-widest">Live Subscriber Counter</p>
                </div>
              </div>

              <div className="text-8xl md:text-9xl font-black tracking-tighter mb-8 tabular-nums">
                {liveSubs.toLocaleString()}
              </div>

              <div className="flex items-center justify-center gap-2 text-green-500 font-bold uppercase tracking-widest text-xs animate-pulse">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                Updating in real-time
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Charts */}
        <div className="lg:col-span-2 space-y-12">
          <div className="bg-white/5 border border-white/10 p-8 rounded-sm">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-xl font-bold uppercase italic tracking-tight">Growth Velocity</h3>
              <div className="flex gap-2">
                <button 
                  onClick={() => setTimeframe(7)}
                  className={`px-3 py-1 text-[10px] font-bold uppercase tracking-widest rounded-sm transition-colors ${timeframe === 7 ? 'bg-[#F27D26] text-black' : 'bg-white/10 text-white hover:bg-white/20'}`}
                >
                  7D
                </button>
                <button 
                  onClick={() => setTimeframe(30)}
                  className={`px-3 py-1 text-[10px] font-bold uppercase tracking-widest rounded-sm transition-colors ${timeframe === 30 ? 'bg-[#F27D26] text-black' : 'bg-white/10 text-white hover:bg-white/20'}`}
                >
                  30D
                </button>
              </div>
            </div>
            <p className="text-white/40 text-[10px] uppercase tracking-widest mb-8 font-bold">Daily subscriber acquisition rate over time.</p>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#F27D26" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#F27D26" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                  <XAxis dataKey="name" stroke="#ffffff40" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#ffffff40" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(1)}K` : value} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#111', border: '1px solid #ffffff20', borderRadius: '4px' }}
                    itemStyle={{ color: '#F27D26' }}
                    formatter={(value: number) => [value.toLocaleString(), "Daily Subscribers"]}
                  />
                  <Area type="monotone" dataKey="subGains" stroke="#F27D26" fillOpacity={1} fill="url(#colorViews)" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white/5 border border-white/10 p-8 rounded-sm">
              <h3 className="text-xl font-bold uppercase italic tracking-tight mb-2">Daily View Trend</h3>
              <p className="text-white/40 text-[10px] uppercase tracking-widest mb-8 font-bold">Visualizing day-to-day view fluctuations.</p>
              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                    <XAxis dataKey="name" stroke="#ffffff40" fontSize={10} tickLine={false} axisLine={false} />
                    <YAxis stroke="#ffffff40" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(1)}K` : value} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#111', border: '1px solid #ffffff20', borderRadius: '4px' }}
                      formatter={(value: number) => [value.toLocaleString(), "Daily Views"]}
                    />
                    <Line type="monotone" dataKey="viewGains" stroke="#3b82f6" strokeWidth={3} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div className="bg-white/5 border border-white/10 p-8 rounded-sm flex flex-col justify-center items-center text-center">
              <div className="w-20 h-20 bg-[#F27D26]/10 rounded-full flex items-center justify-center mb-6">
                <Sparkles className="w-10 h-10 text-[#F27D26]" />
              </div>
              <h3 className="text-2xl font-bold uppercase italic tracking-tight mb-2">Viral Score</h3>
              <p className="text-white/40 text-[10px] uppercase tracking-widest mb-4 font-bold">AI-calculated probability of content going viral.</p>
              <div className="text-6xl font-black text-[#F27D26] tracking-tighter mb-4">{data.advanced?.viralScore || 0}</div>
              <p className="text-white/40 text-xs uppercase tracking-widest font-bold">
                {data.advanced?.viralScore > 80 ? 'High Potential for Growth' : data.advanced?.viralScore > 50 ? 'Steady Engagement' : 'Needs Optimization'}
              </p>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-8">
          <div className="bg-white/5 border border-white/10 p-8 rounded-sm">
            <h3 className="text-xl font-bold uppercase italic tracking-tight mb-2">Channel Health</h3>
            <p className="text-white/40 text-[10px] uppercase tracking-widest mb-6 font-bold">Overall performance metrics and sustainability.</p>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest mb-2">
                  <span className="text-white/40">Consistency</span>
                  <span className={data.advanced?.health?.consistency > 80 ? "text-green-500" : "text-blue-500"}>
                    {data.advanced?.health?.consistency > 80 ? "Excellent" : "Good"}
                  </span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-green-500 transition-all duration-1000" style={{ width: `${data.advanced?.health?.consistency || 0}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest mb-2">
                  <span className="text-white/40">Engagement</span>
                  <span className={data.advanced?.health?.engagement > 80 ? "text-green-500" : "text-blue-500"}>
                    {data.advanced?.health?.engagement > 80 ? "Excellent" : "Good"}
                  </span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 transition-all duration-1000" style={{ width: `${data.advanced?.health?.engagement || 0}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest mb-2">
                  <span className="text-white/40">Retention</span>
                  <span className="text-[#F27D26]">
                    {data.advanced?.health?.retention > 70 ? "Above Average" : "Average"}
                  </span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-[#F27D26] transition-all duration-1000" style={{ width: `${data.advanced?.health?.retention || 0}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
