import React, { useState, useMemo } from "react";
import { 
  Search, Youtube, BookOpen, Globe, Plus, Trash2, BarChart2, TrendingUp, 
  Users, Eye, Video, Loader2, Trophy, Zap, Target, Brain, 
  TrendingDown, Star, Activity, DollarSign, Clock, Layout
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import axios from "axios";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, Legend, LineChart, Line,
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis
} from "recharts";

export default function Compare() {
  const [url, setUrl] = useState("");
  const [creators, setCreators] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [timeframe, setTimeframe] = useState(30);
  const [activeMetricTab, setActiveMetricTab] = useState(0);

  const handleAddCreator = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    if (creators.length >= 4) {
      setError("You can compare up to 4 creators at once.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const response = await axios.post("/api/analyze", { url });
      setCreators([...creators, response.data]);
      setUrl("");
    } catch (err: any) {
      setError(err.response?.data?.error || "Failed to analyze URL.");
    } finally {
      setLoading(false);
    }
  };

  const removeCreator = (id: string) => {
    setCreators(creators.filter(c => c.externalId !== id));
  };

  const metrics = useMemo(() => {
    if (creators.length === 0) return [];
    
    return [
      {
        title: "Audience Scale",
        icon: Users,
        rows: [
          { label: "Subscribers", key: "advanced.comparison.audienceScale.subscribers", format: (v: any) => v.toLocaleString() },
          { label: "Total Views", key: "advanced.comparison.audienceScale.views", format: (v: any) => v.toLocaleString() },
          { label: "Videos", key: "advanced.comparison.audienceScale.videos", format: (v: any) => v.toLocaleString() },
          { label: "Channel Age", key: "advanced.comparison.audienceScale.channelAge", format: (v: any) => `${v}d` },
        ]
      },
      {
        title: "Growth",
        icon: TrendingUp,
        rows: [
          { label: "Daily Gain", key: "advanced.comparison.growth.dailySubGain", format: (v: any) => `+${v.toLocaleString()}` },
          { label: "Weekly %", key: "advanced.comparison.growth.weeklyGrowthRate", format: (v: any) => `${v.toFixed(2)}%` },
          { label: "Monthly %", key: "advanced.comparison.growth.monthlyGrowthRate", format: (v: any) => `${v.toFixed(2)}%` },
          { label: "Velocity", key: "advanced.comparison.growth.growthVelocity", format: (v: any) => `${v.toLocaleString()}/d` },
        ]
      },
      {
        title: "Engagement",
        icon: Activity,
        rows: [
          { label: "Likes/Vid", key: "advanced.comparison.engagement.likesPerVideo", format: (v: any) => v.toLocaleString() },
          { label: "Comments/Vid", key: "advanced.comparison.engagement.commentsPerVideo", format: (v: any) => v.toLocaleString() },
          { label: "Rate %", key: "advanced.comparison.engagement.engagementRate", format: (v: any) => `${v}%` },
          { label: "View/Sub", key: "advanced.comparison.engagement.viewsToSubRatio", format: (v: any) => v.toFixed(2) },
        ]
      },
      {
        title: "Momentum",
        icon: Zap,
        rows: [
          { label: "Spike %", key: "advanced.comparison.momentum.recentGrowthSpike", format: (v: any) => `${v}%` },
          { label: "Trend Score", key: "advanced.comparison.momentum.trendingScore", format: (v: any) => `${v}/100` },
          { label: "Recency", key: "advanced.comparison.momentum.uploadRecency", format: (v: any) => `${v}d` },
          { label: "View Vel", key: "advanced.comparison.momentum.viewVelocity", format: (v: any) => `${v.toLocaleString()}/h` },
        ]
      }
    ];
  }, [creators]);

  const getNestedValue = (obj: any, path: string) => {
    return path.split('.').reduce((acc, part) => acc && acc[part], obj);
  };

  const getWinner = (row: any) => {
    let maxVal = -Infinity;
    let winnerIndex = -1;
    creators.forEach((c, i) => {
      const val = getNestedValue(c, row.key);
      if (typeof val === 'number' && val > maxVal) {
        maxVal = val;
        winnerIndex = i;
      }
    });
    return winnerIndex;
  };

  const radarData = useMemo(() => {
    if (creators.length === 0) return [];
    const axes = ["Growth", "Engagement", "Consistency", "Virality", "Dominance"];
    return axes.map(axis => {
      const data: any = { subject: axis };
      creators.forEach(c => {
        const key = axis.toLowerCase();
        data[c.name] = c.advanced.comparison.aiScores[key === 'virality' ? 'viral' : key] || 50;
      });
      return data;
    });
  }, [creators]);

  const growthHistory = useMemo(() => {
    if (creators.length === 0) return [];
    const days = creators[0].advanced.history.length;
    return Array.from({ length: days }).map((_, i) => {
      const data: any = { name: creators[0].advanced.history[i].name };
      creators.forEach(c => {
        data[c.name] = creators[0].advanced.history[i].subs; // Simplified for visual
      });
      return data;
    });
  }, [creators]);

  const winners = useMemo(() => {
    if (creators.length === 0) return null;
    const fastestGrowing = [...creators].sort((a, b) => b.advanced.comparison.growth.weeklyGrowthRate - a.advanced.comparison.growth.weeklyGrowthRate)[0];
    const bestEngagement = [...creators].sort((a, b) => b.advanced.comparison.engagement.engagementRate - a.advanced.comparison.engagement.engagementRate)[0];
    const mostConsistent = [...creators].sort((a, b) => b.advanced.comparison.content.consistencyScore - a.advanced.comparison.content.consistencyScore)[0];
    return { fastestGrowing, bestEngagement, mostConsistent };
  }, [creators]);

  const colors = ["#F27D26", "#3b82f6", "#10b981", "#a855f7"];

  return (
    <div className="min-h-screen bg-black text-white selection:bg-[#F27D26] selection:text-black">
      {/* Cinematic Header */}
      <div className="relative h-[40vh] flex flex-col items-center justify-center overflow-hidden border-b border-white/5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(242,125,38,0.15)_0%,transparent_70%)]" />
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10 text-center px-4"
        >
          <span className="text-[10px] font-black uppercase tracking-[0.4em] text-[#F27D26] mb-4 block">Strategic Intelligence Arena</span>
          <h1 className="text-7xl md:text-9xl font-black tracking-tighter uppercase italic leading-none mb-8">
            Battle<span className="text-outline-white text-transparent">field</span>
          </h1>
          
          <form onSubmit={handleAddCreator} className="max-w-2xl mx-auto flex gap-2 p-2 bg-white/5 backdrop-blur-xl border border-white/10 rounded-full">
            <div className="relative flex-1">
              <Search className="absolute left-4 w-5 h-5 text-white/40 top-1/2 -translate-y-1/2" />
              <input 
                type="text" 
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="Paste YouTube Channel URL..."
                className="w-full bg-transparent border-none rounded-full py-3 pl-12 pr-4 text-sm font-medium focus:outline-none"
              />
            </div>
            <button 
              type="submit"
              disabled={loading}
              className="px-8 py-3 bg-[#F27D26] text-black font-black uppercase tracking-widest hover:scale-105 transition-all rounded-full flex items-center gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              Add
            </button>
          </form>
          {error && <p className="mt-4 text-red-500 text-[10px] font-black uppercase tracking-widest">{error}</p>}
        </motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {creators.length === 0 ? (
          <div className="py-32 text-center">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ repeat: Infinity, duration: 4 }}
            >
              <Target className="w-24 h-24 text-white/5 mx-auto mb-8" />
            </motion.div>
            <h3 className="text-4xl font-black uppercase italic mb-4 tracking-tighter text-white/20">Awaiting Challengers</h3>
            <p className="text-white/10 text-xs uppercase tracking-[0.3em] font-black max-w-xs mx-auto">Deploy creator URLs to initiate strategic analysis.</p>
          </div>
        ) : (
          <div className="space-y-24">
            
            {/* 1. The Versus Stage */}
            <div className="relative">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 hidden lg:block">
                <div className="w-24 h-24 bg-black border-2 border-[#F27D26] rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(242,125,38,0.3)]">
                  <span className="text-4xl font-black italic text-[#F27D26]">VS</span>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-32">
                {creators.slice(0, 2).map((c, i) => (
                  <motion.div 
                    key={c.externalId}
                    initial={{ x: i === 0 ? -50 : 50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    className={`relative p-8 rounded-2xl border border-white/10 bg-gradient-to-br ${i === 0 ? 'from-[#F27D26]/10 to-transparent' : 'from-blue-500/10 to-transparent'}`}
                  >
                    <div className="flex flex-col items-center text-center">
                      <div className="relative mb-8">
                        <div className="absolute inset-0 bg-[#F27D26] blur-3xl opacity-20 rounded-full" />
                        <img src={c.thumbnail} alt={c.name} className="w-40 h-40 rounded-2xl object-cover border-4 border-white/10 relative z-10" />
                        <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-black border-2 border-white/20 rounded-xl flex items-center justify-center z-20">
                          <Youtube className="w-6 h-6 text-red-500" />
                        </div>
                      </div>
                      
                      <h2 className="text-4xl font-black uppercase italic tracking-tighter mb-2">{c.name}</h2>
                      <p className="text-[#F27D26] font-black text-xs uppercase tracking-widest mb-8">{c.stats.subscribers.toLocaleString()} Subscribers</p>

                      <div className="grid grid-cols-2 gap-4 w-full">
                        {[
                          { label: "Viral Power", val: c.advanced.comparison.aiScores.viral, color: "text-orange-500" },
                          { label: "Growth Vel", val: c.advanced.comparison.aiScores.growth, color: "text-blue-500" },
                          { label: "Consistency", val: c.advanced.comparison.aiScores.consistency, color: "text-green-500" },
                          { label: "Dominance", val: c.advanced.comparison.aiScores.dominance, color: "text-purple-500" },
                        ].map((stat, si) => (
                          <div key={si} className="bg-black/40 border border-white/5 p-4 rounded-xl">
                            <div className="text-[8px] font-black uppercase tracking-widest text-white/30 mb-1">{stat.label}</div>
                            <div className={`text-2xl font-black ${stat.color}`}>{stat.val}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => removeCreator(c.externalId)}
                      className="absolute top-4 right-4 p-2 bg-white/5 hover:bg-red-500/20 text-white/20 hover:text-red-500 rounded-lg transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* 2. Metric Battlegrounds (The "Tug of War") */}
            <div className="space-y-8">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <h3 className="text-2xl font-black uppercase italic tracking-tighter">Metric Battlegrounds</h3>
                <div className="flex gap-4">
                  {metrics.map((m, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveMetricTab(i)}
                      className={`text-[10px] font-black uppercase tracking-widest transition-all ${activeMetricTab === i ? 'text-[#F27D26]' : 'text-white/40 hover:text-white'}`}
                    >
                      {m.title}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {metrics[activeMetricTab].rows.map((row, ri) => {
                  const val1 = getNestedValue(creators[0], row.key) || 0;
                  const val2 = getNestedValue(creators[1], row.key) || 0;
                  const total = val1 + val2;
                  const p1 = total === 0 ? 50 : (val1 / total) * 100;
                  const p2 = 100 - p1;
                  
                  return (
                    <motion.div 
                      key={ri}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: ri * 0.1 }}
                      className="bg-white/5 border border-white/10 p-6 rounded-2xl"
                    >
                      <div className="flex justify-between items-center mb-4">
                        <div className="text-left">
                          <div className="text-[8px] font-black uppercase tracking-widest text-white/30 mb-1">{creators[0]?.name}</div>
                          <div className="text-lg font-black text-[#F27D26]">{row.format(val1)}</div>
                        </div>
                        <div className="text-center px-4 py-1 bg-white/5 rounded-full border border-white/10">
                          <span className="text-[10px] font-black uppercase tracking-widest text-white/60">{row.label}</span>
                        </div>
                        <div className="text-right">
                          <div className="text-[8px] font-black uppercase tracking-widest text-white/30 mb-1">{creators[1]?.name}</div>
                          <div className="text-lg font-black text-blue-500">{row.format(val2)}</div>
                        </div>
                      </div>
                      
                      <div className="relative h-2 bg-white/5 rounded-full overflow-hidden flex">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${p1}%` }}
                          className="h-full bg-[#F27D26]"
                        />
                        <div className="w-[2px] bg-black z-10" />
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${p2}%` }}
                          className="h-full bg-blue-500"
                        />
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* 3. Strategic Bento Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Radar Chart - Large Card */}
              <div className="md:col-span-2 bg-white/5 border border-white/10 p-8 rounded-3xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-8">
                  <Brain className="w-12 h-12 text-white/5 group-hover:text-[#F27D26]/20 transition-colors" />
                </div>
                <h3 className="text-2xl font-black uppercase italic tracking-tighter mb-8">AI Strength Mapping</h3>
                <div className="h-[400px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                      <PolarGrid stroke="#ffffff10" />
                      <PolarAngleAxis dataKey="subject" stroke="#ffffff40" fontSize={10} fontWeight={900} />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#ffffff20" fontSize={8} />
                      {creators.map((c, i) => (
                        <Radar
                          key={c.externalId}
                          name={c.name}
                          dataKey={c.name}
                          stroke={colors[i]}
                          fill={colors[i]}
                          fillOpacity={0.2}
                          strokeWidth={3}
                        />
                      ))}
                      <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #ffffff20', borderRadius: '12px' }} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Winner Highlights - Vertical Stack */}
              <div className="space-y-8">
                {[
                  { label: "Growth King", creator: winners?.fastestGrowing, icon: Trophy, color: "text-yellow-500", bg: "bg-yellow-500/10" },
                  { label: "Engagement Star", creator: winners?.bestEngagement, icon: Star, color: "text-red-500", bg: "bg-red-500/10" },
                  { label: "Consistency Pro", creator: winners?.mostConsistent, icon: Activity, color: "text-blue-500", bg: "bg-blue-500/10" },
                ].map((w, i) => (
                  <motion.div 
                    key={i}
                    whileHover={{ scale: 1.02 }}
                    className="bg-white/5 border border-white/10 p-6 rounded-3xl flex items-center gap-6"
                  >
                    <div className={`w-16 h-16 ${w.bg} rounded-2xl flex items-center justify-center shrink-0`}>
                      <w.icon className={`w-8 h-8 ${w.color}`} />
                    </div>
                    <div>
                      <div className="text-[10px] font-black uppercase tracking-widest text-white/30 mb-1">{w.label}</div>
                      <div className="text-xl font-black uppercase italic tracking-tighter">{w.creator?.name}</div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Growth Trajectory - Full Width */}
              <div className="md:col-span-3 bg-white/5 border border-white/10 p-8 rounded-3xl">
                <div className="flex justify-between items-center mb-12">
                  <div>
                    <h3 className="text-2xl font-black uppercase italic tracking-tighter">Growth Trajectory</h3>
                    <p className="text-[10px] font-black uppercase tracking-widest text-white/30">Historical Subscriber Performance</p>
                  </div>
                  <div className="flex gap-2 bg-black/40 p-1 rounded-xl border border-white/5">
                    {[7, 30, 90].map(d => (
                      <button 
                        key={d}
                        onClick={() => setTimeframe(d)}
                        className={`px-6 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${timeframe === d ? 'bg-[#F27D26] text-black shadow-lg shadow-[#F27D26]/20' : 'text-white/40 hover:text-white'}`}
                      >
                        {d}D
                      </button>
                    ))}
                  </div>
                </div>
                <div className="h-96 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={growthHistory.slice(-timeframe)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                      <XAxis dataKey="name" stroke="#ffffff20" fontSize={10} fontWeight={900} tickLine={false} axisLine={false} dy={10} />
                      <YAxis stroke="#ffffff20" fontSize={10} fontWeight={900} tickLine={false} axisLine={false} tickFormatter={(v) => `${(v/1000000).toFixed(1)}M`} />
                      <Tooltip contentStyle={{ backgroundColor: '#000', border: '1px solid #ffffff20', borderRadius: '12px' }} />
                      {creators.map((c, i) => (
                        <Line 
                          key={c.externalId}
                          type="monotone" 
                          dataKey={c.name} 
                          stroke={colors[i]} 
                          strokeWidth={4} 
                          dot={false}
                          activeDot={{ r: 8, strokeWidth: 0 }}
                        />
                      ))}
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Battle Mode & AI Reasoning */}
              <div className="md:col-span-2 bg-[#F27D26] p-1 rounded-3xl">
                <div className="bg-black h-full rounded-[calc(1.5rem-4px)] p-8 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-8">
                    <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 border border-red-500/20 rounded-full">
                      <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                      <span className="text-[8px] font-black uppercase tracking-widest text-red-500">Live Prediction</span>
                    </div>
                  </div>

                  <h3 className="text-2xl font-black uppercase italic tracking-tighter mb-12">Battle Forecast</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div className="space-y-8">
                      {creators.slice(0, 2).map((c, i) => {
                        const prob = i === 0 ? 68 : 32;
                        return (
                          <div key={i}>
                            <div className="flex justify-between items-end mb-2">
                              <span className="text-xs font-black uppercase tracking-widest text-white/40">{c.name}</span>
                              <span className="text-2xl font-black italic">{prob}%</span>
                            </div>
                            <div className="h-3 bg-white/5 rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${prob}%` }}
                                className={`h-full ${i === 0 ? 'bg-[#F27D26]' : 'bg-blue-500'}`}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    <div className="bg-white/5 border border-white/10 p-6 rounded-2xl flex flex-col justify-center">
                      <div className="flex items-center gap-2 mb-4">
                        <Brain className="w-5 h-5 text-[#F27D26]" />
                        <span className="text-[10px] font-black uppercase tracking-widest text-white/40">AI Logic</span>
                      </div>
                      <p className="text-sm text-white/70 italic leading-relaxed">
                        "Based on current growth velocity and engagement depth, {creators[0]?.name} maintains a statistically significant lead. {creators[1]?.name} requires a 40% increase in upload frequency to challenge the current trajectory."
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actionable Strategy */}
              <div className="bg-white/5 border border-white/10 p-8 rounded-3xl">
                <h3 className="text-2xl font-black uppercase italic tracking-tighter mb-8">Next Moves</h3>
                <div className="space-y-6">
                  {creators.slice(0, 2).map((c, i) => (
                    <div key={i} className="space-y-4">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: colors[i] }} />
                        <span className="text-[10px] font-black uppercase tracking-widest">{c.name}</span>
                      </div>
                      <div className="space-y-2">
                        <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-[10px] font-bold text-white/60">
                          Target high-CTR thumbnails in {c.advanced.comparison.strategy.category}
                        </div>
                        <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-[10px] font-bold text-white/60">
                          Leverage Shorts for 2x reach
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>
        )}
      </div>

      <style>{`
        .text-outline-white {
          -webkit-text-stroke: 1px rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
}
