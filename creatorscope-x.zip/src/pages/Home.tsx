import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { Search, TrendingUp, Youtube, BookOpen, Globe, ArrowRight, Loader2, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import axios from "axios";

export default function Home() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    setLoading(true);
    setError("");
    try {
      const response = await axios.post("/api/analyze", { url });
      const { platform, externalId } = response.data;
      navigate(`/creator/${platform}/${externalId}`, { state: { initialData: response.data } });
    } catch (err: any) {
      setError(err.response?.data?.error || "Failed to analyze URL. Please check the URL and try again.");
    } finally {
      setLoading(false);
    }
  };

  const trendingCreators = [
    { name: "MrBeast", platform: "youtube", id: "UCX6OQ3DkcsbYNE6H8uQQuVA", subs: "300M+", views: "50B+", color: "bg-blue-500", image: "https://unavatar.io/youtube/UCX6OQ3DkcsbYNE6H8uQQuVA" },
    { name: "PewDiePie", platform: "youtube", id: "UC-lHJZR3Gqxm24_Vd_AJ5Yw", subs: "111M+", views: "29B+", color: "bg-red-500", image: "https://unavatar.io/youtube/UC-lHJZR3Gqxm24_Vd_AJ5Yw" },
    { name: "T-Series", platform: "youtube", id: "UCq-Fj5jknLsUf-MWSy4_brA", subs: "260M+", views: "250B+", color: "bg-pink-500", image: "https://unavatar.io/youtube/UCq-Fj5jknLsUf-MWSy4_brA" },
  ];

  const [topLimit, setTopLimit] = useState(10);
  const [selectedCountry, setSelectedCountry] = useState("Global");
  const [hoveredCreator, setHoveredCreator] = useState<string | null>(null);

  const countries = ["Global", "India", "United States", "Australia", "Germany", "United Kingdom", "Canada", "Brazil"];
  
  const topCreatorsData = useMemo(() => {
    // Comprehensive mock data for top creators (Top 10)
    const baseData = [
      // United States (18 entries)
      { rank: 1, name: "MrBeast", subs: "312M", views: "56.2B", country: "United States", category: "Entertainment", grade: "A++", image: "https://unavatar.io/youtube/@MrBeast" },
      { rank: 3, name: "Cocomelon", subs: "178M", views: "182.4B", country: "United States", category: "Education", grade: "A+", image: "https://unavatar.io/youtube/@CoComelon" },
      { rank: 5, name: "Kids Diana Show", subs: "124M", views: "104.1B", country: "United States", category: "Entertainment", grade: "A", image: "https://unavatar.io/youtube/@KidsDianaShow" },
      { rank: 7, name: "Like Nastya", subs: "118M", views: "102.3B", country: "United States", category: "Entertainment", grade: "A", image: "https://unavatar.io/youtube/@LikeNastya" },
      { rank: 8, name: "Vlad and Niki", subs: "121M", views: "92.1B", country: "United States", category: "Entertainment", grade: "A", image: "https://unavatar.io/youtube/@vladandniki" },
      { rank: 10, name: "WWE", subs: "103M", views: "85.2B", country: "United States", category: "Sports", grade: "A", image: "https://unavatar.io/youtube/@WWE" },
      { rank: 12, name: "Dude Perfect", subs: "60M", views: "16.2B", country: "United States", category: "Sports", grade: "A-", image: "https://unavatar.io/youtube/@DudePerfect" },
      { rank: 15, name: "Markiplier", subs: "36M", views: "21.1B", country: "United States", category: "Gaming", grade: "B+", image: "https://unavatar.io/youtube/@markiplier" },
      { rank: 19, name: "MrBeast Gaming", subs: "41M", views: "12.5B", country: "United States", category: "Gaming", grade: "A-", image: "https://unavatar.io/youtube/@MrBeastGaming" },
      { rank: 21, name: "Ryan's World", subs: "37M", views: "56.1B", country: "United States", category: "Entertainment", grade: "B+", image: "https://unavatar.io/youtube/@RyansWorld" },
      { rank: 24, name: "Logan Paul", subs: "23M", views: "6.1B", country: "United States", category: "Entertainment", grade: "B", image: "https://unavatar.io/youtube/@LoganPaul" },
      { rank: 28, name: "Jake Paul", subs: "20M", views: "7.2B", country: "United States", category: "Sports", grade: "B", image: "https://unavatar.io/youtube/@JakePaul" },
      { rank: 32, name: "Ninja", subs: "23M", views: "2.5B", country: "United States", category: "Gaming", grade: "B-", image: "https://unavatar.io/youtube/@Ninja" },
      { rank: 35, name: "Dream", subs: "31M", views: "3.1B", country: "United States", category: "Gaming", grade: "B", image: "https://unavatar.io/youtube/@dream" },
      { rank: 42, name: "Veritasium", subs: "15M", views: "2.1B", country: "United States", category: "Education", grade: "B+", image: "https://unavatar.io/youtube/@veritasium" },
      { rank: 44, name: "Smosh", subs: "26M", views: "10.2B", country: "United States", category: "Comedy", grade: "B", image: "https://unavatar.io/youtube/@smosh" },
      { rank: 47, name: "Linus Tech Tips", subs: "15M", views: "7.5B", country: "United States", category: "Tech", grade: "B+", image: "https://unavatar.io/youtube/@LinusTechTips" },
      { rank: 49, name: "Marques Brownlee", subs: "18M", views: "3.8B", country: "United States", category: "Tech", grade: "B+", image: "https://unavatar.io/youtube/@MKBHD" },
      
      // India (18 entries)
      { rank: 2, name: "T-Series", subs: "271M", views: "262.1B", country: "India", category: "Music", grade: "A++", image: "https://unavatar.io/youtube/@tseries" },
      { rank: 4, name: "SET India", subs: "175M", views: "164.2B", country: "India", category: "Entertainment", grade: "A+", image: "https://unavatar.io/youtube/@setindia" },
      { rank: 9, name: "Zee Music Company", subs: "109M", views: "65.4B", country: "India", category: "Music", grade: "A", image: "https://unavatar.io/youtube/@zeemusiccompany" },
      { rank: 11, name: "Goldmines", subs: "98M", views: "25.1B", country: "India", category: "Film", grade: "A-", image: "https://unavatar.io/youtube/@GoldminesTelefilms" },
      { rank: 13, name: "Sony SAB", subs: "94M", views: "112.3B", country: "India", category: "Entertainment", grade: "A-", image: "https://unavatar.io/youtube/@sonysab" },
      { rank: 18, name: "CarryMinati", subs: "42M", views: "3.5B", country: "India", category: "Comedy", grade: "B", image: "https://unavatar.io/youtube/@CarryMinati" },
      { rank: 23, name: "Total Gaming", subs: "40M", views: "6.2B", country: "India", category: "Gaming", grade: "B+", image: "https://unavatar.io/youtube/@TotalGaming093" },
      { rank: 26, name: "Techno Gamerz", subs: "38M", views: "10.1B", country: "India", category: "Gaming", grade: "B+", image: "https://unavatar.io/youtube/@TechnoGamerzOfficial" },
      { rank: 29, name: "Round2hell", subs: "33M", views: "3.2B", country: "India", category: "Comedy", grade: "B", image: "https://unavatar.io/youtube/@Round2hell" },
      { rank: 31, name: "Ashish Chanchlani", subs: "30M", views: "4.5B", country: "India", category: "Comedy", grade: "B", image: "https://unavatar.io/youtube/@ashishchanchlanivines" },
      { rank: 34, name: "BB Ki Vines", subs: "26M", views: "4.8B", country: "India", category: "Comedy", grade: "B-", image: "https://unavatar.io/youtube/@BBKiVines" },
      { rank: 38, name: "Technical Guruji", subs: "23M", views: "3.1B", country: "India", category: "Tech", grade: "B-", image: "https://unavatar.io/youtube/@TechnicalGuruji" },
      { rank: 41, name: "Sandeep Maheshwari", subs: "28M", views: "2.5B", country: "India", category: "Education", grade: "B", image: "https://unavatar.io/youtube/@SandeepSeminars" },
      { rank: 45, name: "Amit Bhadana", subs: "24M", views: "2.3B", country: "India", category: "Comedy", grade: "B-", image: "https://unavatar.io/youtube/@AmitBhadana" },
      { rank: 50, name: "FactTechz", subs: "20M", views: "2.1B", country: "India", category: "Education", grade: "C+", image: "https://unavatar.io/youtube/@FactTechz" },
      { rank: 52, name: "Emiway Bantai", subs: "21M", views: "3.5B", country: "India", category: "Music", grade: "B", image: "https://unavatar.io/youtube/@EmiwayBantai" },
      { rank: 54, name: "Flying Beast", subs: "8M", views: "2.1B", country: "India", category: "Vlogs", grade: "B-", image: "https://unavatar.io/youtube/@FlyingBeast320" },
      { rank: 56, name: "Sourav Joshi Vlogs", subs: "25M", views: "9.2B", country: "India", category: "Vlogs", grade: "A-", image: "https://unavatar.io/youtube/@souravjoshivlogs7028" },
      
      // Australia (7 entries)
      { rank: 20, name: "Bounce Patrol", subs: "28M", views: "22.1B", country: "Australia", category: "Education", grade: "B+", image: "https://unavatar.io/youtube/@BouncePatrol" },
      { rank: 25, name: "LazarBeam", subs: "21M", views: "8.2B", country: "Australia", category: "Gaming", grade: "B", image: "https://unavatar.io/youtube/@LazarBeam" },
      { rank: 30, name: "Chloe Ting", subs: "24M", views: "3.1B", country: "Australia", category: "Fitness", grade: "B-", image: "https://unavatar.io/youtube/@ChloeTing" },
      { rank: 36, name: "How Ridiculous", subs: "15M", views: "6.5B", country: "Australia", category: "Entertainment", grade: "B", image: "https://unavatar.io/youtube/@howridiculous" },
      { rank: 43, name: "Muselk", subs: "9M", views: "3.8B", country: "Australia", category: "Gaming", grade: "C+", image: "https://unavatar.io/youtube/@muselk" },
      { rank: 48, name: "Primitive Technology", subs: "10M", views: "1.1B", country: "Australia", category: "Education", grade: "B-", image: "https://unavatar.io/youtube/@primitivetechnology9550" },
      { rank: 58, name: "RackaRacka", subs: "6M", views: "1.2B", country: "Australia", category: "Entertainment", grade: "C", image: "https://unavatar.io/youtube/@therackaracka" },
      
      // Germany (7 entries)
      { rank: 22, name: "Kurzgesagt", subs: "22M", views: "2.5B", country: "Germany", category: "Education", grade: "B+", image: "https://unavatar.io/youtube/@kurzgesagt" },
      { rank: 40, name: "Freekickerz", subs: "9M", views: "2.8B", country: "Germany", category: "Sports", grade: "C+", image: "https://unavatar.io/youtube/@freekickerz" },
      { rank: 46, name: "Julien Bam", subs: "6M", views: "1.5B", country: "Germany", category: "Entertainment", grade: "C", image: "https://unavatar.io/youtube/@JulienBam" },
      { rank: 55, name: "Gronkh", subs: "5M", views: "3.5B", country: "Germany", category: "Gaming", grade: "C", image: "https://unavatar.io/youtube/@Gronkh" },
      { rank: 60, name: "BibisBeautyPalace", subs: "6M", views: "2.8B", country: "Germany", category: "Lifestyle", grade: "C", image: "https://unavatar.io/youtube/@BibisBeautyPalace" },
      { rank: 62, name: "Dagi Bee", subs: "4M", views: "1.1B", country: "Germany", category: "Lifestyle", grade: "C-", image: "https://unavatar.io/youtube/@DagiBee" },
      { rank: 65, name: "Paluten", subs: "5M", views: "4.2B", country: "Germany", category: "Gaming", grade: "B-", image: "https://unavatar.io/youtube/@Paluten" },
    ];

    // Filter by country
    let filtered = selectedCountry === "Global" 
      ? [...baseData] 
      : baseData.filter(c => c.country === selectedCountry);
    
    // Sort by rank (Global rank)
    filtered.sort((a, b) => a.rank - b.rank);

    // If we need more data for Top 10, generate HIGH QUALITY placeholder items
    // only if the filtered list is still too short.
    if (filtered.length < topLimit) {
      const remaining = topLimit - filtered.length;
      const lastRank = filtered.length > 0 ? filtered[filtered.length - 1].rank : 60;
      
      for (let i = 1; i <= remaining; i++) {
        const currentRank = lastRank + i;
        filtered.push({
          rank: currentRank,
          name: `${selectedCountry === "Global" ? "Global" : selectedCountry} Elite ${i}`,
          subs: `${Math.floor(Math.random() * 10) + 5}M`,
          views: `${(Math.random() * 5 + 1).toFixed(1)}B`,
          country: selectedCountry === "Global" ? "International" : selectedCountry,
          category: ["Entertainment", "Gaming", "Education", "Music"][Math.floor(Math.random() * 4)],
          grade: ["B+", "B", "B-", "C+"][Math.floor(Math.random() * 4)],
          image: null
        });
      }
    }

    // STRICTLY return only the requested limit
    return filtered.slice(0, topLimit);
  }, [selectedCountry, topLimit]);

  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <div className="inline-block px-3 py-1 bg-[#F27D26]/10 border border-[#F27D26]/20 rounded-full mb-8">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#F27D26]">Next-Gen Analytics Engine</span>
          </div>
          <h1 className="text-7xl md:text-9xl font-bold tracking-tighter uppercase italic leading-[0.85] mb-8">
            Analyze <br />
            <span className="text-[#F27D26]">Everything.</span>
          </h1>
          <p className="max-w-2xl mx-auto text-white/60 text-lg mb-12 font-medium">
            Real-time social analytics, AI-powered growth predictions, and deep insights for the world's top creators.
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="max-w-3xl mx-auto relative group">
            <div className="relative flex items-center">
              <Search className="absolute left-6 w-6 h-6 text-white/40 group-focus-within:text-[#F27D26] transition-colors" />
              <input 
                type="text" 
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="Paste YouTube Channel URL, Medium, or Blogger link..."
                className="w-full bg-white/5 border-2 border-white/10 rounded-sm py-6 pl-16 pr-32 text-xl font-medium focus:outline-none focus:border-[#F27D26] transition-all placeholder:text-white/20"
              />
              <button 
                type="submit"
                disabled={loading}
                className="absolute right-3 px-6 py-3 bg-[#F27D26] text-black font-bold uppercase tracking-wider hover:bg-[#ff8c3a] transition-colors rounded-sm flex items-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Analyze"}
              </button>
            </div>
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 p-4 bg-red-500/10 border border-red-500/20 rounded-sm text-red-500 text-sm font-bold uppercase tracking-widest flex flex-col items-center gap-2"
              >
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  {error}
                </div>
                {error.includes("API Key") && (
                  <p className="text-[10px] text-white/40 normal-case font-medium mt-1">
                    Go to Settings &gt; Secrets and add <b>YOUTUBE_API_KEY</b> with your key from Google Cloud Console.
                  </p>
                )}
              </motion.div>
            )}
          </form>
        </motion.div>
      </section>

      {/* Platforms Section */}
      <section className="py-20 bg-white/5 border-y border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="flex flex-col items-center text-center group">
              <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Youtube className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-xl font-bold uppercase italic mb-2 tracking-tight">YouTube Data API</h3>
              <p className="text-white/40 text-sm">Full channel stats, subscriber history, and video performance metrics.</p>
            </div>
            <div className="flex flex-col items-center text-center group">
              <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <BookOpen className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-bold uppercase italic mb-2 tracking-tight">Medium Scraping</h3>
              <p className="text-white/40 text-sm">Clap counts, follower growth, and post engagement analysis.</p>
            </div>
            <div className="flex flex-col items-center text-center group">
              <div className="w-16 h-16 bg-orange-500/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Globe className="w-8 h-8 text-orange-500" />
              </div>
              <h3 className="text-xl font-bold uppercase italic mb-2 tracking-tight">Blogger Insights</h3>
              <p className="text-white/40 text-sm">Traffic patterns and content velocity for independent publishers.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Top Creators Section */}
      <section className="py-32 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-8 mb-16">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#F27D26] mb-2 block">Global Benchmarks</span>
            <h2 className="text-5xl font-bold tracking-tighter uppercase italic">Top Creators</h2>
            <div className="flex gap-4 mt-4">
              <button className="flex items-center gap-2 px-4 py-2 bg-red-500/10 border border-red-500/20 rounded-sm text-red-500 text-[10px] font-black uppercase tracking-widest">
                <Youtube className="w-3 h-3" /> YouTube
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-sm text-white/20 text-[10px] font-black uppercase tracking-widest cursor-not-allowed">
                <BookOpen className="w-3 h-3" /> Medium
              </button>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-4">
            {/* Limit Filter Removed - Locked to Top 10 */}

            {/* Country Filter */}
            <select 
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="bg-white/5 border border-white/10 rounded-sm px-4 py-2 text-[10px] font-bold uppercase tracking-widest focus:outline-none focus:border-[#F27D26] transition-all text-white/60"
            >
              {countries.map(country => (
                <option key={country} value={country} className="bg-black text-white">{country}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="relative bg-white/5 border border-white/10 rounded-sm overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-white/5 border-b border-white/10">
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-white/40">Rank</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-white/40">Creator</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-white/40">Subscribers</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-white/40">Views</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-white/40 hidden md:table-cell">Category</th>
                <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-white/40 text-center">Grade</th>
              </tr>
            </thead>
            <tbody>
              {topCreatorsData.map((creator, index) => (
                <tr 
                  key={`${creator.name}-${index}`}
                  onMouseEnter={() => setHoveredCreator(creator.name)}
                  onMouseLeave={() => setHoveredCreator(null)}
                  className="border-b border-white/5 hover:bg-white/10 transition-all cursor-pointer relative group"
                >
                  <td className="px-6 py-6 text-sm font-bold text-white/40">
                    #{selectedCountry === "Global" ? creator.rank : index + 1}
                  </td>
                  <td className="px-6 py-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-[#F27D26]/20 rounded-sm overflow-hidden flex items-center justify-center text-[#F27D26] font-bold">
                        {creator.image ? (
                          <img src={creator.image} alt={creator.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          creator.name.charAt(0)
                        )}
                      </div>
                      <div>
                        <div className="text-sm font-bold uppercase italic group-hover:text-[#F27D26] transition-colors">{creator.name}</div>
                        <div className="text-[10px] font-medium text-white/20 uppercase tracking-widest">{creator.country}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-6 text-sm font-bold tracking-tighter">{creator.subs}</td>
                  <td className="px-6 py-6 text-sm font-medium text-white/60">{creator.views}</td>
                  <td className="px-6 py-6 text-[10px] font-bold uppercase tracking-widest text-white/40 hidden md:table-cell">{creator.category}</td>
                  <td className="px-6 py-6 text-center relative">
                    <span className="px-3 py-1 bg-green-500/10 text-green-500 text-[10px] font-black rounded-sm border border-green-500/20">
                      {creator.grade}
                    </span>

                    {/* Hover Pop-up Effect */}
                    <AnimatePresence>
                      {hoveredCreator === creator.name && (
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.95, x: 20 }}
                          animate={{ opacity: 1, scale: 1, x: 0 }}
                          exit={{ opacity: 0, scale: 0.95, x: 20 }}
                          className="absolute left-[100%] top-1/2 -translate-y-1/2 ml-4 z-50 bg-black border border-[#F27D26]/30 p-6 rounded-sm shadow-[0_0_50px_rgba(242,125,38,0.2)] pointer-events-none hidden lg:block min-w-[300px]"
                        >
                          <div className="flex items-center gap-4 mb-4 text-left">
                            <div className="w-16 h-16 bg-[#F27D26] rounded-sm overflow-hidden flex items-center justify-center text-black text-2xl font-black italic">
                              {creator.image ? (
                                <img src={creator.image} alt={creator.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              ) : (
                                creator.name.charAt(0)
                              )}
                            </div>
                            <div>
                              <h4 className="text-xl font-black uppercase italic tracking-tighter text-white">{creator.name}</h4>
                              <p className="text-[10px] font-bold text-[#F27D26] uppercase tracking-[0.2em]">{creator.category}</p>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="bg-white/5 p-3 rounded-sm text-left">
                              <div className="text-[8px] font-bold uppercase tracking-widest text-white/30 mb-1">Weekly Growth</div>
                              <div className="text-sm font-bold text-green-500">+1.2M</div>
                            </div>
                            <div className="bg-white/5 p-3 rounded-sm text-left">
                              <div className="text-[8px] font-bold uppercase tracking-widest text-white/30 mb-1">Engagement</div>
                              <div className="text-sm font-bold text-blue-500">8.4%</div>
                            </div>
                          </div>
                          <div className="mt-4 pt-4 border-t border-white/10 flex justify-between items-center">
                            <span className="text-[8px] font-bold uppercase tracking-widest text-white/20">Market Dominance</span>
                            <div className="h-1 bg-white/10 w-24 rounded-full overflow-hidden">
                              <div className="h-full bg-[#F27D26] w-[85%]"></div>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Trending Section */}
      <section className="py-32 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-16">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#F27D26] mb-2 block">Market Leaders</span>
            <h2 className="text-5xl font-bold tracking-tighter uppercase italic">Trending Creators</h2>
          </div>
          <button className="text-sm font-bold uppercase tracking-widest text-white/40 hover:text-white flex items-center gap-2 group">
            View All <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {trendingCreators.map((creator, i) => (
            <motion.div 
              key={creator.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => navigate(`/creator/${creator.platform}/${creator.id}`)}
              className="bg-white/5 border border-white/10 p-8 rounded-sm hover:border-[#F27D26]/50 transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-start mb-8">
                <div className={`w-12 h-12 ${creator.color} rounded-sm overflow-hidden flex items-center justify-center`}>
                  {creator.image ? (
                    <img src={creator.image} alt={creator.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <Youtube className="w-6 h-6 text-white" />
                  )}
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold uppercase tracking-widest text-white/40 mb-1">Subscribers</div>
                  <div className="text-2xl font-bold tracking-tighter">{creator.subs}</div>
                </div>
              </div>
              <h3 className="text-2xl font-bold uppercase italic mb-1 group-hover:text-[#F27D26] transition-colors">{creator.name}</h3>
              <div className="text-xs font-medium text-white/40 uppercase tracking-widest mb-6">Total Views: {creator.views}</div>
              <div className="h-1 bg-white/10 w-full rounded-full overflow-hidden">
                <div className="h-full bg-[#F27D26] w-[70%]"></div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
