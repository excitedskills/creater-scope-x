import { useState, useRef, useEffect } from "react";
import { MessageSquare, X, Send, Sparkles, Loader2, Bot, Trash2, User, Zap } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { GoogleGenAI } from "@google/genai";
import ReactMarkdown from "react-markdown";

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<{ role: "user" | "ai"; content: string }[]>([
    { role: "ai", content: "Hello! I'm your **CreatorScope AI** assistant. I provide real-time, data-driven answers about creator performance. How can I help you today?" }
  ]);
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const creatorData = (window as any).currentCreatorData;

  const clearChat = () => {
    setMessages([{ role: "ai", content: "Chat cleared. How else can I help you?" }]);
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    console.log("AI Assistant: Current Creator Data:", creatorData ? creatorData.name : "None");
    if (isOpen && creatorData && messages.length === 1) {
      setMessages(prev => [...prev, { 
        role: "ai", 
        content: `I see you're looking at **${creatorData.name}**. Would you like me to generate a deep-dive AI analysis for this creator?` 
      }]);
    }
  }, [isOpen, creatorData]);

  const handleSend = async (e?: React.FormEvent, customPrompt?: string) => {
    if (e) e.preventDefault();
    const userMessage = customPrompt || input.trim();
    if (!userMessage && !customPrompt) return;
    if (loading) return;

    if (!customPrompt) setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setLoading(true);

    try {
      const isPlaceholder = (val?: string) => !val || val === "MY_GEMINI_API_KEY" || val === "YOUR_API_KEY" || val === "";

      // Check multiple sources for the API key
      let apiKey = [
        process.env.GEMINI_API_KEY,
        process.env.API_KEY,
        process.env.GOOGLE_API_KEY,
        (import.meta as any).env?.VITE_GEMINI_API_KEY,
        (import.meta as any).env?.VITE_API_KEY,
        (window as any).GEMINI_API_KEY,
        (window as any).API_KEY,
        (window as any).GOOGLE_API_KEY,
        (window as any).aistudio?.API_KEY,
        (window as any).aistudio?.GEMINI_API_KEY,
        (window as any).aistudio?.selectedApiKey
      ].find(key => !isPlaceholder(key)) || "";

      let debugInfo = {
        client: {
          processEnv: !!process.env.GEMINI_API_KEY,
          processEnvApiKey: !!process.env.API_KEY,
          processEnvGoogleKey: !!process.env.GOOGLE_API_KEY,
          viteEnv: !!(import.meta as any).env?.VITE_GEMINI_API_KEY,
          window: !!(window as any).GEMINI_API_KEY,
        },
        server: null as any
      };

      // Fallback: Try to fetch from server if not found in environment
      if (!apiKey) {
        try {
          const configRes = await fetch("/api/config");
          const configData = await configRes.json();
          debugInfo.server = configData.debug;
          if (configData.geminiKey) {
            apiKey = configData.geminiKey;
            console.log("AI Assistant: API Key fetched from server fallback.");
          }
        } catch (e) {
          console.error("AI Assistant: Failed to fetch API key from server fallback:", e);
        }
      }

      console.log("AI Assistant: API Key Detection:", {
        ...debugInfo,
        finalStatus: apiKey ? `Present (Length: ${apiKey.length})` : "Missing"
      });
      
      if (!apiKey) {
        const debugStr = JSON.stringify(debugInfo, null, 2);
        throw new Error(`Gemini API Key is missing. \n\nDebug Info:\n${debugStr}\n\nIf you are using the AI Studio Free Tier, please ensure the key is correctly linked in the Secrets panel and that you have refreshed the page.`);
      }
      
      const ai = new GoogleGenAI({ apiKey });
      
      let contextPrompt = "";
      if (creatorData) {
        contextPrompt = `Context: You are analyzing the creator "${creatorData.name}" on ${creatorData.platform}. 
        Stats: ${JSON.stringify(creatorData.stats)}. 
        Advanced Metrics: Grade ${creatorData.advanced?.grade}, Viral Score ${creatorData.advanced?.viralScore}.`;
      }

      const prompt = `You are the **CreatorScope AI Agent**, a high-precision real-time analytics assistant.
      
${creatorData ? `CURRENT CREATOR CONTEXT:
- Name: ${creatorData.name}
- Platform: ${creatorData.platform}
- Current Total Subs: ${creatorData.stats.subs}
- Current Total Views: ${creatorData.stats.views}
- History (Last 30 Days): ${JSON.stringify(creatorData.advanced.history)}
- Advanced Metrics: ${JSON.stringify(creatorData.advanced)}
` : "No specific creator context is currently selected."}

CORE DIRECTIVES:
1. **Direct Answer Only**: Provide the exact answer to the user's question. Do NOT provide a "deep analysis" or "growth deep-dive" unless explicitly requested.
2. **Data Accuracy**: Use the provided context data to give perfect, accurate numbers. 
3. **Weekly Stats Calculation**: 
   - The 'History' array is ordered from oldest to newest (the last element is today).
   - To calculate "last week" (last 7 days), sum the 'subGains' or 'viewGains' for the **last 7 entries** in the History array.
   - Show your calculation if it helps clarity (e.g., "Sum of last 7 days: X + Y + ... = Z").
4. **Conciseness**: Keep responses brief and to the point.
5. **Tone**: Professional, efficient, and data-focused.

User Query: "${userMessage}"`;

      // Build the full contents array with history
      const historyContents = messages.map(msg => ({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: msg.content }]
      }));

      // Add the current prompt
      const contents = [
        ...historyContents.slice(1), // Skip the initial greeting to keep it clean
        { role: "user", parts: [{ text: prompt }] }
      ];

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: contents,
      });
      
      if (!response.text) {
        throw new Error("No response text from AI model");
      }

      setMessages(prev => [...prev, { role: "ai", content: response.text }]);
    } catch (error: any) {
      console.error("AI Assistant error:", error);
      const errorMessage = error.message || "An unknown error occurred.";
      setMessages(prev => [...prev, { 
        role: "ai", 
        content: `Sorry, I encountered an error: **${errorMessage}**. Please check your browser console (F12) for more details.` 
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 30, rotateX: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0, rotateX: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 30, rotateX: 10 }}
            className="absolute bottom-20 right-0 w-[440px] h-[700px] bg-[#050505]/95 border border-[#39FF14]/40 rounded-3xl shadow-[0_0_80px_rgba(57,255,20,0.2)] flex flex-col overflow-hidden backdrop-blur-2xl perspective-1000"
          >
            {/* Neon Scanning Line */}
            <motion.div 
              animate={{ top: ["0%", "100%", "0%"] }}
              transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
              className="absolute left-0 right-0 h-[1px] bg-[#F27D26]/40 shadow-[0_0_15px_#F27D26] z-20 pointer-events-none"
            />

            {/* Header */}
            <div className="p-6 bg-black border-b border-[#F27D26]/20 flex justify-between items-center relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-r from-[#F27D26]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="flex items-center gap-4 relative z-10">
                <div className="w-11 h-11 bg-[#F27D26] rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(242,125,38,0.5)]">
                  <motion.div
                    animate={{ rotate: [0, 360] }}
                    transition={{ repeat: Infinity, duration: 10, ease: "linear" }}
                  >
                    <Zap className="w-6 h-6 text-black fill-black" />
                  </motion.div>
                </div>
                <div>
                  <h3 className="font-black uppercase tracking-tighter italic leading-none text-lg text-[#F27D26] drop-shadow-[0_0_8px_rgba(242,125,38,0.5)]">
                    CREATOR CORE <span className="text-white">v2.5</span>
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="w-2 h-2 bg-[#F27D26] rounded-full animate-pulse shadow-[0_0_8px_#F27D26]" />
                    <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">System Synchronized</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 relative z-10">
                <button 
                  onClick={clearChat}
                  className="hover:bg-[#F27D26]/10 p-2.5 rounded-xl transition-all hover:scale-110 active:scale-90 text-white/40 hover:text-[#F27D26]"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => setIsOpen(false)} 
                  className="hover:bg-[#F27D26]/10 p-2.5 rounded-xl transition-all hover:scale-110 active:scale-90 text-white/40 hover:text-[#F27D26]"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-10 scrollbar-hide relative">
              {/* Animated Grid Background */}
              <div className="absolute inset-0 opacity-[0.05] pointer-events-none bg-[linear-gradient(to_right,#F27D26_1px,transparent_1px),linear-gradient(to_bottom,#F27D26_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,black,transparent)]" />
              
              {messages.map((msg, i) => (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  key={i} 
                  className={`flex gap-5 relative z-10 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
                >
                  <div className={`w-12 h-12 rounded-2xl flex-shrink-0 flex items-center justify-center border-2 transition-all duration-500 ${
                    msg.role === "user" 
                      ? "bg-[#F27D26] border-white/20 text-black shadow-[0_0_25px_rgba(242,125,38,0.4)]" 
                      : "bg-black border-[#F27D26]/40 text-[#F27D26] shadow-[0_0_20px_rgba(242,125,38,0.2)]"
                  }`}>
                    {msg.role === "user" ? <User className="w-6 h-6" /> : <Bot className="w-6 h-6" />}
                  </div>
                  
                  <div className={`flex flex-col gap-3 max-w-[82%] ${msg.role === "user" ? "items-end" : "items-start"}`}>
                    <div className={`p-6 rounded-[2rem] text-sm leading-relaxed shadow-2xl backdrop-blur-xl border transition-all duration-500 ${
                      msg.role === "user" 
                        ? "bg-[#F27D26] text-black font-black rounded-tr-none border-white/20" 
                        : "bg-white/[0.04] border-white/10 text-white/90 rounded-tl-none hover:border-[#F27D26]/30"
                    }`}>
                      <div className="markdown-content max-w-none">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    </div>
                    
                    {msg.role === "ai" && i === messages.length - 1 && creatorData && !loading && (
                      <div className="flex gap-3 mt-2">
                        <button 
                          onClick={() => handleSend(undefined, "Analyze the growth trends from the last 30 days.")}
                          className="px-4 py-2 bg-black hover:bg-[#F27D26] border border-[#F27D26]/40 hover:border-[#F27D26] rounded-xl text-[10px] font-black uppercase tracking-widest text-[#F27D26] hover:text-black transition-all flex items-center gap-2 shadow-[0_0_15px_rgba(242,125,38,0.1)] hover:shadow-[0_0_20px_rgba(242,125,38,0.4)]"
                        >
                          <Zap className="w-3.5 h-3.5" />
                          Growth Analysis
                        </button>
                        <button 
                          onClick={() => handleSend(undefined, "What is the predicted subscriber count for next month?")}
                          className="px-4 py-2 bg-black hover:bg-[#F27D26] border border-[#F27D26]/40 hover:border-[#F27D26] rounded-xl text-[10px] font-black uppercase tracking-widest text-[#F27D26] hover:text-black transition-all flex items-center gap-2 shadow-[0_0_15px_rgba(242,125,38,0.1)] hover:shadow-[0_0_20_rgba(242,125,38,0.4)]"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          Predictions
                        </button>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
              
              {loading && (
                <div className="flex gap-5 relative z-10">
                  <div className="w-12 h-12 rounded-2xl bg-black border-2 border-[#F27D26]/40 flex items-center justify-center shadow-[0_0_20px_rgba(242,125,38,0.2)]">
                    <Bot className="w-6 h-6 text-[#F27D26]" />
                  </div>
                  <div className="bg-white/[0.04] border border-white/10 p-6 rounded-[2rem] rounded-tl-none backdrop-blur-xl">
                    <div className="flex gap-3">
                      <motion.div animate={{ scale: [1, 1.8, 1], opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.2 }} className="w-2.5 h-2.5 bg-[#F27D26] rounded-full shadow-[0_0_12px_#F27D26]" />
                      <motion.div animate={{ scale: [1, 1.8, 1], opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.2, delay: 0.2 }} className="w-2.5 h-2.5 bg-[#F27D26] rounded-full shadow-[0_0_12px_#F27D26]" />
                      <motion.div animate={{ scale: [1, 1.8, 1], opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1.2, delay: 0.4 }} className="w-2.5 h-2.5 bg-[#F27D26] rounded-full shadow-[0_0_12px_#F27D26]" />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Input Area */}
            <div className="p-8 border-t border-[#F27D26]/20 bg-black relative z-10">
              <form onSubmit={handleSend} className="relative group">
                <div className="absolute -inset-1.5 bg-gradient-to-r from-[#F27D26] to-[#ff8c3a] rounded-2xl blur-lg opacity-0 group-focus-within:opacity-30 transition-opacity duration-700" />
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Query the Creator Core..."
                  className="relative w-full bg-white/[0.05] border border-white/10 rounded-2xl py-5 pl-7 pr-16 text-sm focus:outline-none focus:border-[#F27D26] focus:ring-4 focus:ring-[#F27D26]/10 transition-all placeholder:text-white/10 text-white font-bold tracking-wide"
                />
                <button 
                  type="submit"
                  disabled={loading || !input.trim()}
                  className={`absolute right-3 top-1/2 -translate-y-1/2 p-3.5 rounded-xl transition-all duration-500 ${
                    input.trim() && !loading 
                      ? "bg-[#F27D26] text-black shadow-[0_0_25px_rgba(242,125,38,0.5)] hover:scale-110 active:scale-90" 
                      : "text-white/10 bg-white/5 cursor-not-allowed"
                  }`}
                >
                  <Send className="w-6 h-6" />
                </button>
              </form>
              <div className="flex justify-between items-center mt-5 px-2">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-[#F27D26] rounded-full animate-ping" />
                  <span className="text-[10px] text-[#F27D26] font-black uppercase tracking-[0.2em]">Neural Link Established</span>
                </div>
                <p className="text-[10px] text-white/20 font-black uppercase tracking-[0.2em]">
                  SECURE CHANNEL
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-[0_10px_30px_rgba(242,125,38,0.3)] hover:scale-110 active:scale-95 transition-all group relative overflow-hidden ${
          isOpen ? "bg-white text-black" : "bg-[#F27D26] text-black"
        }`}
      >
        <div className="absolute inset-0 bg-gradient-to-tr from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ rotate: -90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: 90, opacity: 0 }}
            >
              <X className="w-7 h-7" />
            </motion.div>
          ) : (
            <motion.div
              key="open"
              initial={{ rotate: 90, opacity: 0 }}
              animate={{ rotate: 0, opacity: 1 }}
              exit={{ rotate: -90, opacity: 0 }}
              className="relative"
            >
              <MessageSquare className="w-7 h-7" />
              <motion.div 
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute -top-3 -right-3 w-5 h-5 bg-white rounded-full flex items-center justify-center border-2 border-[#050505]"
              >
                <Sparkles className="w-2.5 h-2.5 text-[#39FF14] fill-[#39FF14]" />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </button>
    </div>
  );
}
