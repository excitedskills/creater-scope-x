import { ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, BarChart2, LayoutDashboard, User, LogIn, LogOut, TrendingUp } from "lucide-react";
import { auth } from "../firebase";
import { signInWithPopup, GoogleAuthProvider, signOut } from "firebase/auth";
import { motion } from "motion/react";
import AIAssistant from "./AIAssistant";

interface LayoutProps {
  children: ReactNode;
  user: any;
}

export default function Layout({ children, user }: LayoutProps) {
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate("/");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-[#F27D26] selection:text-black">
      {/* Navigation */}
      <nav className="border-b border-white/10 bg-[#050505]/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-8">
              <Link to="/" className="flex items-center gap-2 group">
                <div className="w-8 h-8 bg-[#F27D26] rounded-sm flex items-center justify-center transform rotate-45 group-hover:rotate-90 transition-transform duration-300">
                  <TrendingUp className="w-5 h-5 text-black -rotate-45 group-hover:-rotate-90 transition-transform duration-300" />
                </div>
                <span className="text-xl font-bold tracking-tighter uppercase italic">CreatorScope X</span>
              </Link>
              
              <div className="hidden md:flex items-center gap-6">
                <Link to="/" className="text-sm font-medium text-white/60 hover:text-[#F27D26] transition-colors">Explore</Link>
                <Link to="/compare" className="text-sm font-medium text-white/60 hover:text-[#F27D26] transition-colors">Compare</Link>
                {user && (
                  <Link to="/dashboard" className="text-sm font-medium text-white/60 hover:text-[#F27D26] transition-colors">Dashboard</Link>
                )}
              </div>
            </div>

            <div className="flex items-center gap-4">
              {user ? (
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-full border border-white/10">
                    <img src={user.photoURL} alt={user.displayName} className="w-6 h-6 rounded-full" />
                    <span className="text-xs font-medium text-white/80 hidden sm:inline">{user.displayName}</span>
                  </div>
                  <button 
                    onClick={handleLogout}
                    className="p-2 text-white/60 hover:text-[#F27D26] transition-colors"
                    title="Logout"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <button 
                  onClick={handleLogin}
                  className="flex items-center gap-2 px-4 py-2 bg-[#F27D26] text-black text-sm font-bold uppercase tracking-wider hover:bg-[#ff8c3a] transition-colors rounded-sm"
                >
                  <LogIn className="w-4 h-4" />
                  Connect
                </button>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        {children}
      </main>

      {/* AI Assistant */}
      <AIAssistant />

      {/* Footer */}
      <footer className="border-t border-white/10 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="text-2xl font-bold tracking-tighter uppercase italic mb-4 opacity-20">CreatorScope X</div>
          <p className="text-white/40 text-xs uppercase tracking-widest">© 2026 Full Power Analytics Engine. Built with Gemini AI.</p>
        </div>
      </footer>
    </div>
  );
}
