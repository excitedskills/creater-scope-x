import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import axios from "axios";
import { GoogleGenAI } from "@google/genai";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Helper to extract YouTube Channel ID or Handle
function extractYouTubeId(url: string) {
  const channelMatch = url.match(/youtube\.com\/channel\/([^\/\?]+)/);
  if (channelMatch) return { type: 'id', value: channelMatch[1] };
  
  const handleMatch = url.match(/youtube\.com\/@([^\/\?]+)/);
  if (handleMatch) return { type: 'handle', value: handleMatch[1] };
  
  const userMatch = url.match(/youtube\.com\/user\/([^\/\?]+)/);
  if (userMatch) return { type: 'user', value: userMatch[1] };

  return null;
}

// API Routes
app.get("/api/config", (req, res) => {
  const isPlaceholder = (val?: string) => !val || val === "MY_GEMINI_API_KEY" || val === "YOUR_API_KEY" || val === "";
  
  const geminiKey = [
    process.env.GEMINI_API_KEY,
    process.env.API_KEY,
    process.env.GOOGLE_API_KEY,
    process.env.VITE_GEMINI_API_KEY
  ].find(key => !isPlaceholder(key)) || null;

  const keys = {
    GEMINI_API_KEY: process.env.GEMINI_API_KEY ? `Present (${process.env.GEMINI_API_KEY.length})` : "Missing",
    API_KEY: process.env.API_KEY ? `Present (${process.env.API_KEY.length})` : "Missing",
    GOOGLE_API_KEY: process.env.GOOGLE_API_KEY ? `Present (${process.env.GOOGLE_API_KEY.length})` : "Missing",
    VITE_GEMINI_API_KEY: process.env.VITE_GEMINI_API_KEY ? `Present (${process.env.VITE_GEMINI_API_KEY.length})` : "Missing",
  };
  
  console.log("Server: Config request, keys found:", keys);
  
  res.json({
    hasGeminiKey: !!geminiKey,
    geminiKey: geminiKey,
    debug: keys
  });
});

app.post("/api/analyze", async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: "URL is required" });

  const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY;

  try {
    if (url.includes("youtube.com")) {
      if (!YOUTUBE_API_KEY || YOUTUBE_API_KEY === "MY_YOUTUBE_API_KEY" || YOUTUBE_API_KEY === "") {
        return res.status(500).json({ error: "YouTube API Key is missing or invalid. Please add a valid YOUTUBE_API_KEY to your secrets." });
      }

      const ytInfo = extractYouTubeId(url);
      if (!ytInfo) return res.status(400).json({ error: "Invalid YouTube URL" });

      let channelId = "";
      if (ytInfo.type === 'id') {
        channelId = ytInfo.value;
      } else if (ytInfo.type === 'handle') {
        // Use forHandle parameter for handles
        const handleUrl = `https://www.googleapis.com/youtube/v3/channels?part=id&forHandle=@${ytInfo.value}&key=${YOUTUBE_API_KEY}`;
        const handleRes = await axios.get(handleUrl);
        if (!handleRes.data.items || handleRes.data.items.length === 0) {
          // Fallback to search if forHandle fails (some handles might be tricky)
          const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&q=${ytInfo.value}&key=${YOUTUBE_API_KEY}`;
          const searchRes = await axios.get(searchUrl);
          if (!searchRes.data.items || searchRes.data.items.length === 0) return res.status(404).json({ error: "Channel not found" });
          channelId = searchRes.data.items[0].id.channelId;
        } else {
          channelId = handleRes.data.items[0].id;
        }
      } else {
        // Search for channel by username
        const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&q=${ytInfo.value}&key=${YOUTUBE_API_KEY}`;
        const searchRes = await axios.get(searchUrl);
        if (!searchRes.data.items || searchRes.data.items.length === 0) return res.status(404).json({ error: "Channel not found" });
        channelId = searchRes.data.items[0].id.channelId;
      }

      const statsUrl = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,brandingSettings&id=${channelId}&key=${YOUTUBE_API_KEY}`;
      const statsRes = await axios.get(statsUrl);
      if (!statsRes.data.items || statsRes.data.items.length === 0) return res.status(404).json({ error: "Channel not found" });

      const channel = statsRes.data.items[0];
      const subs = parseInt(channel.statistics.subscriberCount) || 0;
      const views = parseInt(channel.statistics.viewCount) || 0;
      const videos = parseInt(channel.statistics.videoCount) || 0;

      // Social Blade-like Calculations
      const calculateGrade = (subs: number, views: number) => {
        if (subs > 100000000) return "A++";
        if (subs > 50000000) return "A+";
        if (subs > 10000000) return "A";
        if (subs > 1000000) return "A-";
        if (subs > 500000) return "B+";
        if (subs > 100000) return "B";
        return "C";
      };

      const estimateEarnings = (views: number) => {
        const monthlyViews = views / 120; // Rough estimate of monthly views from total
        const lowCPM = 0.25;
        const highCPM = 4.00;
        return {
          monthlyLow: (monthlyViews / 1000) * lowCPM,
          monthlyHigh: (monthlyViews / 1000) * highCPM,
          yearlyLow: (monthlyViews / 1000) * lowCPM * 12,
          yearlyHigh: (monthlyViews / 1000) * highCPM * 12,
        };
      };

      const generateProjections = (subs: number) => {
        const dailyGrowth = subs * 0.0005; // Mock growth rate
        return [
          { timeframe: "2 Months", subs: Math.floor(subs + dailyGrowth * 60) },
          { timeframe: "6 Months", subs: Math.floor(subs + dailyGrowth * 180) },
          { timeframe: "1 Year", subs: Math.floor(subs + dailyGrowth * 365) },
          { timeframe: "5 Years", subs: Math.floor(subs + dailyGrowth * 1825) },
        ];
      };

      const generateHistory = (subs: number, views: number) => {
        const history = [];
        const dailySubGrowth = subs * 0.0005;
        const dailyViewGrowth = views * 0.001;
        
        let currentSubs = subs;
        let currentViews = views;
        
        // Generate from today backwards
        for (let i = 0; i < 30; i++) {
          const date = new Date();
          date.setDate(date.getDate() - i);
          
          const subGain = Math.floor(dailySubGrowth + (Math.random() * dailySubGrowth * 0.4) - (dailySubGrowth * 0.2));
          const viewGain = Math.floor(dailyViewGrowth + (Math.random() * dailyViewGrowth * 0.6) - (dailyViewGrowth * 0.3));
          
          history.unshift({
            name: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            subs: currentSubs,
            views: currentViews,
            subGains: subGain,
            viewGains: viewGain,
          });
          
          currentSubs -= subGain;
          currentViews -= viewGain;
        }
        return history;
      };

      const calculateViralScore = (subs: number, views: number, videos: number) => {
        if (videos === 0) return 0;
        const avgViewsPerVideo = views / videos;
        const engagementRatio = avgViewsPerVideo / (subs || 1);
        let score = Math.min(100, Math.floor(engagementRatio * 500));
        if (subs > 1000000) score += 10;
        return Math.min(100, score);
      };

      const calculateHealth = (subs: number, views: number, videos: number) => {
        const consistency = Math.min(100, Math.floor((videos / 100) * 100));
        const engagement = Math.min(100, Math.floor((views / (subs * 10 || 1)) * 100));
        const retention = Math.min(100, 60 + Math.floor(Math.random() * 30));
        return { consistency, engagement, retention };
      };

      const generateComparisonMetrics = (subs: number, views: number, videos: number) => {
        const avgViews = videos > 0 ? views / videos : 0;
        const engagementRate = (avgViews / (subs || 1)) * 10;
        const dailySubGain = Math.floor(subs * 0.0005);
        
        return {
          audienceScale: {
            subscribers: subs,
            views: views,
            videos: videos,
            channelAge: Math.floor(Math.random() * 2000) + 365, // days
          },
          growth: {
            dailySubGain,
            weeklyGrowthRate: 1.2 + (Math.random() * 2),
            monthlyGrowthRate: 5.5 + (Math.random() * 10),
            growthVelocity: dailySubGain,
          },
          engagement: {
            likesPerVideo: Math.floor(avgViews * 0.05),
            commentsPerVideo: Math.floor(avgViews * 0.01),
            engagementRate: parseFloat(engagementRate.toFixed(2)),
            viewsToSubRatio: parseFloat((views / (subs || 1)).toFixed(2)),
          },
          content: {
            avgViewsPerVideo: Math.floor(avgViews),
            topVideoPerformance: Math.floor(views * 0.15),
            consistencyScore: Math.floor(Math.random() * 40) + 60,
            viralVideoCount: Math.floor(videos * 0.05),
          },
          momentum: {
            recentGrowthSpike: Math.random() > 0.7 ? 25 : 5,
            trendingScore: Math.floor(Math.random() * 50) + 50,
            uploadRecency: Math.floor(Math.random() * 7), // days ago
            viewVelocity: Math.floor(avgViews / 24), // views/hour
          },
          monetization: {
            estimatedEarnings: (views / 1000) * 2,
            cpmRange: "$2.50 - $8.00",
            brandValueScore: Math.floor(Math.random() * 30) + 70,
          },
          strategy: {
            videoLengthPattern: "12-15 mins",
            postingTimePattern: "6 PM EST",
            category: "Entertainment",
            titleEffectiveness: Math.floor(Math.random() * 20) + 80,
          },
          aiScores: {
            viral: Math.floor(Math.random() * 40) + 60,
            growth: Math.floor(Math.random() * 40) + 60,
            consistency: Math.floor(Math.random() * 40) + 60,
            dominance: Math.floor(Math.random() * 40) + 60,
          }
        };
      };

      const data = {
        platform: "youtube",
        externalId: channel.id,
        name: channel.snippet.title,
        description: channel.snippet.description,
        thumbnail: channel.snippet.thumbnails.high.url,
        stats: {
          subscribers: subs,
          views: views,
          videoCount: videos,
        },
        advanced: {
          grade: calculateGrade(subs, views),
          earnings: estimateEarnings(views),
          projections: generateProjections(subs),
          history: generateHistory(subs, views),
          viralScore: calculateViralScore(subs, views, videos),
          health: calculateHealth(subs, views, videos),
          rank: Math.floor(Math.random() * 10000) + 1,
          comparison: generateComparisonMetrics(subs, views, videos),
        },
        banner: channel.brandingSettings?.image?.bannerExternalUrl || null,
      };

      return res.json(data);
    } else if (url.includes("medium.com") || url.includes("blogger.com")) {
      // Basic simulation for Medium/Blogger as full scraping requires Puppeteer which might be heavy for this environment
      // In a real production app, we'd use a dedicated scraping service or Puppeteer on a worker.
      return res.json({
        platform: url.includes("medium") ? "medium" : "blogger",
        externalId: "mock-id-" + Date.now(),
        name: "Creator Name",
        description: "Creator description from " + (url.includes("medium") ? "Medium" : "Blogger"),
        thumbnail: "https://picsum.photos/seed/creator/200",
        stats: {
          subscribers: Math.floor(Math.random() * 10000),
          views: Math.floor(Math.random() * 100000),
          posts: Math.floor(Math.random() * 50),
        }
      });
    }

    res.status(400).json({ error: "Unsupported platform" });
  } catch (error: any) {
    const errorData = error.response?.data;
    console.error("Analysis error:", JSON.stringify(errorData || error.message, null, 2));
    
    const googleReason = errorData?.error?.errors?.[0]?.reason;
    const googleMessage = errorData?.error?.message;

    if (googleReason === "keyInvalid" || googleMessage?.includes("API key")) {
      return res.status(500).json({ error: "Invalid YouTube API Key. Please ensure you've copied it correctly into Settings > Secrets." });
    }
    
    if (googleReason === "accessNotConfigured") {
      return res.status(500).json({ error: "YouTube Data API v3 is not enabled in your Google Cloud Console." });
    }

    if (googleReason === "quotaExceeded") {
      return res.status(500).json({ error: "YouTube API Quota exceeded. Please try again later or use a different key." });
    }
    
    res.status(500).json({ error: "Analysis failed: " + (googleMessage || error.message) });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    
    // Log ALL environment variables (names only for security, except for lengths of keys)
    console.log("Server: Environment Variables Check:");
    Object.keys(process.env).forEach(key => {
      const value = process.env[key];
      if (key.includes("KEY") || key.includes("SECRET") || key.includes("TOKEN")) {
        console.log(`  - ${key}: Present (Length: ${value?.length || 0})`);
      } else {
        console.log(`  - ${key}: ${value ? "Present" : "Missing"}`);
      }
    });

    console.log("Server: API Key Status Summary:", {
      GEMINI_API_KEY: process.env.GEMINI_API_KEY ? `Present (Length: ${process.env.GEMINI_API_KEY.length})` : "Missing",
      API_KEY: process.env.API_KEY ? `Present (Length: ${process.env.API_KEY.length})` : "Missing",
      GOOGLE_API_KEY: process.env.GOOGLE_API_KEY ? `Present (Length: ${process.env.GOOGLE_API_KEY.length})` : "Missing",
      YOUTUBE_API_KEY: process.env.YOUTUBE_API_KEY ? `Present (Length: ${process.env.YOUTUBE_API_KEY.length})` : "Missing"
    });
  });
}

startServer();
